from django.shortcuts import render

# Create your views here.


def home(request):
    return render(request, 'Core/index.html',)


def CadastrosClientes(request):
    return render(request, 'Core/cadastrosClientes.html',)